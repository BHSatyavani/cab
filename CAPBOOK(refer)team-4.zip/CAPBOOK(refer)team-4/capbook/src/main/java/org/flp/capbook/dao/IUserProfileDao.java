package org.flp.capbook.dao;

import java.util.List;

import org.flp.capbook.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("userprofiledao")
@Transactional

public interface IUserProfileDao extends JpaRepository<UserProfile,Integer> {

	List<UserProfile> findAll();
	@Query("select userName from UserProfile where userId =:id")
	String getUserName(@Param("id")Integer Id);

}
