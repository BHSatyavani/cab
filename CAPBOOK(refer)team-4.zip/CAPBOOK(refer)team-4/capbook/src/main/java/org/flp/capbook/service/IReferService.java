package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;



public interface IReferService {

List<String> getAllFriendRequest1(Integer userId);

 
}
